# Business Documents Web Package

Drop these files into any static website or repo.

## Files
- `invoice.html`
- `bill-of-lading.html`
- `receipt.html`
- `assets/business-docs.css`
- `assets/business-docs.js`

## How to use
Keep the folder structure intact:

business-documents/
  invoice.html
  bill-of-lading.html
  receipt.html
  assets/
    business-docs.css
    business-docs.js

Then browse to:
- `/business-documents/invoice.html`
- `/business-documents/bill-of-lading.html`
- `/business-documents/receipt.html`

Each page:
- is mobile-friendly
- allows direct editing in the browser
- calculates totals
- supports Print / Save as PDF
- can export entered form data as JSON

## Integration
You can link to the pages from your website:

<a href="/business-documents/invoice.html">Create Invoice</a>
<a href="/business-documents/bill-of-lading.html">Create Bill of Lading</a>
<a href="/business-documents/receipt.html">Create Receipt</a>

These are frontend templates only. They do not store records on a server. For permanent records, invoice numbering, database storage, customer accounts, email delivery, or PDF generation on the backend, connect the form fields to your existing API/database.
