
(function(){
  const $ = (q,root=document)=>root.querySelector(q);
  const $$ = (q,root=document)=>[...root.querySelectorAll(q)];

  window.printDocument = () => window.print();

  window.addLine = function(tableId){
    const tbody = document.querySelector(`#${tableId} tbody`);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input class="desc" placeholder="Description"></td>
      <td><input class="qty" type="number" min="0" step="1" value="1"></td>
      <td><input class="rate" type="number" min="0" step="0.01" value="0"></td>
      <td class="num line-total">0.00</td>
      <td class="no-print"><button class="secondary" onclick="this.closest('tr').remove();recalc()">×</button></td>`;
    tbody.appendChild(tr);
    recalc();
  };

  window.recalc = function(){
    let subtotal = 0;
    $$(".line-total").forEach(cell=>{
      const row = cell.closest("tr");
      const qty = parseFloat($(".qty",row)?.value || 0);
      const rate = parseFloat($(".rate",row)?.value || 0);
      const line = qty * rate;
      cell.textContent = line.toFixed(2);
      subtotal += line;
    });
    const tax = parseFloat($("#tax")?.value || 0);
    const discount = parseFloat($("#discount")?.value || 0);
    const taxAmt = subtotal * tax / 100;
    const total = Math.max(0, subtotal + taxAmt - discount);
    if($("#subtotal")) $("#subtotal").textContent = subtotal.toFixed(2);
    if($("#taxAmount")) $("#taxAmount").textContent = taxAmt.toFixed(2);
    if($("#grandTotal")) $("#grandTotal").textContent = total.toFixed(2);
    if($("#amountPaid") && $("#balanceDue")){
      const paid = parseFloat($("#amountPaid").value || 0);
      $("#balanceDue").textContent = Math.max(0,total-paid).toFixed(2);
    }
  };

  document.addEventListener("input", e=>{
    if(e.target.matches(".qty,.rate,#tax,#discount,#amountPaid")) recalc();
  });

  window.downloadJSON = function(type){
    const fields = {};
    $$("[data-field]").forEach(el=>fields[el.dataset.field]=el.value ?? el.textContent);
    const blob = new Blob([JSON.stringify({document_type:type, ...fields}, null, 2)], {type:"application/json"});
    const a=document.createElement("a");
    a.href=URL.createObjectURL(blob);
    a.download=(fields.number || type).replace(/[^\w-]+/g,"_")+".json";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  recalc();
})();
